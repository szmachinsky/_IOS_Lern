# NTPagedTableViewController

An example of a subclass of UITableView with "snapping",as UIScrollView's pagingEnabled, using: -(void)scrollViewWillEndDragging: withVelocity: targetContentOffset:

