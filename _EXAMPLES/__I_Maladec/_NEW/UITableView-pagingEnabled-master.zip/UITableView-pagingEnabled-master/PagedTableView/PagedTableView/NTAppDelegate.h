//
//  NTAppDelegate.h
//  PagedTableView
//
//  Created by Nao Tokui on 5/1/13.
//  Copyright (c) 2013 Nao Tokui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UIViewController *viewController;

@end
