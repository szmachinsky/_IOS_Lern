//
//  NTPagedTableViewController.h
//  PagedTableView
//
//  Created by Nao Tokui on 5/1/13.
//  Copyright (c) 2013 Nao Tokui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTPagedTableViewController : UITableViewController

@property BOOL centering;

@end
