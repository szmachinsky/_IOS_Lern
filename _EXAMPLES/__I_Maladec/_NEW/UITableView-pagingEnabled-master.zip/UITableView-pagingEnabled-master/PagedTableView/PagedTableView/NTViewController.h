//
//  NTViewController.h
//  PagedTableView
//
//  Created by Nao Tokui on 5/2/13.
//  Copyright (c) 2013 Nao Tokui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTViewController : UIViewController

- (IBAction) buttonPressed: (UIButton *)sender;

@end
