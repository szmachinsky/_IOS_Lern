WritingAnimationMessageView
===========================

alert text message with typing animation
