//
//  AppDelegate.h
//  ScrollingNavigationDemo
//
//  Created by Loganathan on 04/03/13.
//  Copyright (c) 2013 Loganathan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
