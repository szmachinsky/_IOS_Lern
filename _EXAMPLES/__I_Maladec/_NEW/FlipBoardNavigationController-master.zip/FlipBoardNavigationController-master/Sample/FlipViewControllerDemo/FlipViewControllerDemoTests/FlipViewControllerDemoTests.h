//
//  FlipViewControllerDemoTests.h
//  FlipViewControllerDemoTests
//
//  Created by Michael henry Pantaleon on 5/2/13.
//  Copyright (c) 2013 Michael Henry Pantaleon. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface FlipViewControllerDemoTests : SenTestCase

@end
