//
//  FlipViewControllerDemoTests.m
//  FlipViewControllerDemoTests
//
//  Created by Michael henry Pantaleon on 5/2/13.
//  Copyright (c) 2013 Michael Henry Pantaleon. All rights reserved.
//

#import "FlipViewControllerDemoTests.h"

@implementation FlipViewControllerDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in FlipViewControllerDemoTests");
}

@end
