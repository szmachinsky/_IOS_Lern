//
//  ViewController.h
//  DropdownTable
//
//  Created by Alximik on 22.02.13.
//  Copyright (c) 2013 Unotion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController

@property (strong, nonatomic) NSArray *students;

@end
