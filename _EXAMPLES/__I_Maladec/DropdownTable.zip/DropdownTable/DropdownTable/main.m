//
//  main.m
//  DropdownTable
//
//  Created by Alximik on 22.02.13.
//  Copyright (c) 2013 Unotion. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
