//
//  UISearchDisplayTutorialAppDelegate.h
//  UISearchDisplayTutorial
//
//  Created by Alximik on 15.09.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UISearchDisplayTutorialAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end
