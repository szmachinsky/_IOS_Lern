//
//  NSTimerDemoViewController.h
//  NSTimerDemo
//
//  Created by Collin Ruffenach on 7/21/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSTimerDemoViewController : UIViewController 
{
	NSTimer *myTimer;
}

@end

